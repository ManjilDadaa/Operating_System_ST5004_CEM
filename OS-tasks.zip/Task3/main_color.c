#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

/* ─────────────────────────────────────────────────
   ANSI COLOURS
───────────────────────────────────────────────── */
#define RESET   "\033[0m"
#define BOLD    "\033[1m"
#define DIM     "\033[2m"
#define RED     "\033[31m"
#define GREEN   "\033[32m"
#define YELLOW  "\033[33m"
#define BLUE    "\033[34m"
#define CYAN    "\033[36m"
#define CLEAR   "\033[2J\033[H"

/* ─────────────────────────────────────────────────
   CONSTANTS
───────────────────────────────────────────────── */
#define MAX_USERS       5
#define MAX_USERNAME    32
#define MAX_PASSWORD    64
#define AUDIT_LOG       "audit.log"
#define USER_DB         "users.db"
#define FILES_DIR       "fs_files"
#define XOR_KEY         0x5A   /* encryption key — simple XOR cipher */

/* ─────────────────────────────────────────────────
   PERMISSION BITS
   Modelled after Unix rwx for owner / group / others
   Each is a bitmask:
     owner:  bits 8-6
     group:  bits 5-3
     others: bits 2-0
───────────────────────────────────────────────── */
#define PERM_OWNER_R  0400
#define PERM_OWNER_W  0200
#define PERM_OWNER_X  0100
#define PERM_GROUP_R  0040
#define PERM_GROUP_W  0020
#define PERM_GROUP_X  0010
#define PERM_OTHER_R  0004
#define PERM_OTHER_W  0002
#define PERM_OTHER_X  0001

/* ─────────────────────────────────────────────────
   USER STRUCT
───────────────────────────────────────────────── */
typedef struct {
    char username[MAX_USERNAME];
    char password_hash[MAX_PASSWORD]; /* XOR-hashed password stored as hex */
    int  is_owner;                    /* 1 = owner/admin, 0 = regular user  */
} User;

/* ─────────────────────────────────────────────────
   SESSION — currently logged-in user
───────────────────────────────────────────────── */
User  current_user;
int   logged_in = 0;

/* ─────────────────────────────────────────────────
   SIMPLE HASH
   XOR every byte with KEY, encode as 2-digit hex.
   Not cryptographic — used to show the concept of
   not storing plaintext passwords.
───────────────────────────────────────────────── */
void hash_password(const char *password, char *out_hex) {
    int len = strlen(password);
    for (int i = 0; i < len; i++)
        sprintf(out_hex + i * 2, "%02x",
                (unsigned char)(password[i] ^ XOR_KEY));
    out_hex[len * 2] = '\0';
}

/* ─────────────────────────────────────────────────
   AUDIT LOG
   Every file operation is recorded with:
   timestamp | username | action | filename
───────────────────────────────────────────────── */
void audit(const char *action, const char *filename) {
    FILE *f = fopen(AUDIT_LOG, "a");
    if (!f) return;
    time_t now = time(NULL);
    char ts[32];
    strftime(ts, sizeof(ts), "%Y-%m-%d %H:%M:%S", localtime(&now));
    fprintf(f, "[%s] USER=%-12s ACTION=%-10s FILE=%s\n",
            ts,
            logged_in ? current_user.username : "anonymous",
            action,
            filename ? filename : "-");
    fclose(f);
}

/* ─────────────────────────────────────────────────
   PERMISSION STRING
   Converts octal permission int to rwxrwxrwx string
───────────────────────────────────────────────── */
void perm_to_str(int perm, char *out) {
    out[0] = (perm & PERM_OWNER_R) ? 'r' : '-';
    out[1] = (perm & PERM_OWNER_W) ? 'w' : '-';
    out[2] = (perm & PERM_OWNER_X) ? 'x' : '-';
    out[3] = (perm & PERM_GROUP_R) ? 'r' : '-';
    out[4] = (perm & PERM_GROUP_W) ? 'w' : '-';
    out[5] = (perm & PERM_GROUP_X) ? 'x' : '-';
    out[6] = (perm & PERM_OTHER_R) ? 'r' : '-';
    out[7] = (perm & PERM_OTHER_W) ? 'w' : '-';
    out[8] = (perm & PERM_OTHER_X) ? 'x' : '-';
    out[9] = '\0';
}

/* ─────────────────────────────────────────────────
   USER DATABASE HELPERS
───────────────────────────────────────────────── */
int load_users(User *users, int *count) {
    FILE *f = fopen(USER_DB, "r");
    if (!f) { *count = 0; return 0; }
    *count = 0;
    while (*count < MAX_USERS &&
           fscanf(f, "%31s %63s %d",
                  users[*count].username,
                  users[*count].password_hash,
                  &users[*count].is_owner) == 3)
        (*count)++;
    fclose(f);
    return 1;
}

void save_users(User *users, int count) {
    FILE *f = fopen(USER_DB, "w");
    if (!f) return;
    for (int i = 0; i < count; i++)
        fprintf(f, "%s %s %d\n",
                users[i].username,
                users[i].password_hash,
                users[i].is_owner);
    fclose(f);
}

/* ─────────────────────────────────────────────────
   PRINT HEADER
───────────────────────────────────────────────── */
void print_header(void) {
    printf(BOLD BLUE
        "\n╔══════════════════════════════════════════════════════╗\n"
        "║   ST5004CEM Task 3 — Secure File Management System  ║\n"
        "╚══════════════════════════════════════════════════════╝\n"
        RESET);
    if (logged_in)
        printf(DIM "  Logged in as: " RESET CYAN "%s" RESET
               DIM " (%s)\n\n" RESET,
               current_user.username,
               current_user.is_owner ? "owner" : "user");
}

/* ─────────────────────────────────────────────────
   3.1.2 — USER AUTHENTICATION
───────────────────────────────────────────────── */

/* Register a new user */
int register_user(const char *username, const char *password, int is_owner) {
    User users[MAX_USERS];
    int count = 0;
    load_users(users, &count);

    /* Check for duplicate */
    for (int i = 0; i < count; i++)
        if (strcmp(users[i].username, username) == 0) {
            printf(RED "  Error: username '%s' already exists.\n" RESET, username);
            return 0;
        }

    if (count >= MAX_USERS) {
        printf(RED "  Error: user limit reached.\n" RESET);
        return 0;
    }

    strncpy(users[count].username, username, MAX_USERNAME - 1);
    hash_password(password, users[count].password_hash);
    users[count].is_owner = is_owner;
    count++;
    save_users(users, count);

    printf(GREEN "  User '%s' registered successfully.\n" RESET, username);
    audit("REGISTER", username);
    return 1;
}

/* Login */
int login(const char *username, const char *password) {
    User users[MAX_USERS];
    int count = 0;
    load_users(users, &count);

    char hashed[MAX_PASSWORD];
    hash_password(password, hashed);

    for (int i = 0; i < count; i++) {
        if (strcmp(users[i].username, username) == 0 &&
            strcmp(users[i].password_hash, hashed) == 0) {
            current_user = users[i];
            logged_in = 1;
            printf(GREEN "  Login successful. Welcome, %s!\n" RESET, username);
            audit("LOGIN", NULL);
            return 1;
        }
    }
    printf(RED "  Login failed: invalid username or password.\n" RESET);
    audit("LOGIN_FAIL", username);
    return 0;
}

void logout(void) {
    if (!logged_in) { printf(RED "  Not logged in.\n" RESET); return; }
    audit("LOGOUT", NULL);
    printf(YELLOW "  Logged out: %s\n" RESET, current_user.username);
    logged_in = 0;
    memset(&current_user, 0, sizeof(current_user));
}

/* ─────────────────────────────────────────────────
   3.1.3 — FILE PERMISSIONS
   Permission metadata stored in a .meta sidecar file
   next to the actual file. Format:
     owner permissions
   e.g.:  manjil 0640
───────────────────────────────────────────────── */
void meta_path(const char *filename, char *out) {
    snprintf(out, 256, "%s/.%s.meta", FILES_DIR, filename);
}

void write_meta(const char *filename, const char *owner, int perm) {
    char mp[256];
    meta_path(filename, mp);
    FILE *f = fopen(mp, "w");
    if (!f) return;
    fprintf(f, "%s %o\n", owner, perm);
    fclose(f);
}

int read_meta(const char *filename, char *owner, int *perm) {
    char mp[256];
    meta_path(filename, mp);
    FILE *f = fopen(mp, "r");
    if (!f) return 0;
    fscanf(f, "%31s %o", owner, perm);
    fclose(f);
    return 1;
}

/*
 * check_permission — decides if the current user
 * can perform an action on a file.
 *
 * needed: PERM_OWNER_R / PERM_OWNER_W / etc.
 * The function checks:
 *   - if current user is the file owner → use owner bits
 *   - otherwise → use others bits
 *   (group logic simplified: non-owner = others)
 */
int check_permission(const char *filename, int needed_owner_bit, int needed_other_bit) {
    if (!logged_in) { printf(RED "  Not logged in.\n" RESET); return 0; }
    char owner[MAX_USERNAME];
    int perm = 0;
    if (!read_meta(filename, owner, &perm)) {
        printf(RED "  No metadata for '%s'. Does the file exist?\n" RESET, filename);
        return 0;
    }
    if (strcmp(owner, current_user.username) == 0)
        return (perm & needed_owner_bit) ? 1 : 0;
    else
        return (perm & needed_other_bit) ? 1 : 0;
}

/* ─────────────────────────────────────────────────
   3.1.4 — XOR ENCRYPTION / DECRYPTION
   XOR with a fixed key byte-by-byte.
   Same function encrypts and decrypts (XOR is symmetric).
───────────────────────────────────────────────── */
void xor_crypt(const char *in_path, const char *out_path) {
    FILE *in  = fopen(in_path,  "rb");
    FILE *out = fopen(out_path, "wb");
    if (!in || !out) {
        printf(RED "  Encryption error: cannot open files.\n" RESET);
        if (in)  fclose(in);
        if (out) fclose(out);
        return;
    }
    int c;
    while ((c = fgetc(in)) != EOF)
        fputc(c ^ XOR_KEY, out);
    fclose(in);
    fclose(out);
}

/* ─────────────────────────────────────────────────
   FILE PATH HELPER
───────────────────────────────────────────────── */
void file_path(const char *filename, char *out) {
    snprintf(out, 256, "%s/%s", FILES_DIR, filename);
}

/* ─────────────────────────────────────────────────
   3.1.1 — FILE OPERATIONS
───────────────────────────────────────────────── */

/* CREATE — make a new file with given content and permissions */
int fs_create(const char *filename, const char *content, int perm) {
    if (!logged_in) { printf(RED "  Not logged in.\n" RESET); return 0; }

    char fp[256];
    file_path(filename, fp);

    /* Check it doesn't already exist */
    if (access(fp, F_OK) == 0) {
        printf(RED "  Error: '%s' already exists.\n" RESET, filename);
        return 0;
    }

    FILE *f = fopen(fp, "w");
    if (!f) { printf(RED "  Error: cannot create '%s'.\n" RESET, filename); return 0; }
    fprintf(f, "%s", content);
    fclose(f);

    write_meta(filename, current_user.username, perm);

    char pstr[10];
    perm_to_str(perm, pstr);
    printf(GREEN "  Created '%s'  permissions: %s  owner: %s\n" RESET,
           filename, pstr, current_user.username);
    audit("CREATE", filename);
    return 1;
}

/* READ — print file contents if permitted */
int fs_read(const char *filename) {
    if (!check_permission(filename, PERM_OWNER_R, PERM_OTHER_R)) {
        printf(RED "  Permission denied: read on '%s'\n" RESET, filename);
        audit("READ_DENIED", filename);
        return 0;
    }
    char fp[256];
    file_path(filename, fp);
    FILE *f = fopen(fp, "r");
    if (!f) { printf(RED "  Error: '%s' not found.\n" RESET, filename); return 0; }

    printf(CYAN "\n  ── Contents of '%s' ──\n" RESET, filename);
    int c;
    while ((c = fgetc(f)) != EOF) putchar(c);
    printf(CYAN "\n  ────────────────────────\n" RESET);
    fclose(f);
    audit("READ", filename);
    return 1;
}

/* WRITE — append content to file if permitted */
int fs_write(const char *filename, const char *content) {
    if (!check_permission(filename, PERM_OWNER_W, PERM_OTHER_W)) {
        printf(RED "  Permission denied: write on '%s'\n" RESET, filename);
        audit("WRITE_DENIED", filename);
        return 0;
    }
    char fp[256];
    file_path(filename, fp);
    FILE *f = fopen(fp, "a");
    if (!f) { printf(RED "  Error opening '%s' for write.\n" RESET, filename); return 0; }
    fprintf(f, "%s", content);
    fclose(f);
    printf(GREEN "  Written to '%s' successfully.\n" RESET, filename);
    audit("WRITE", filename);
    return 1;
}

/* DELETE — remove file and its metadata if permitted */
int fs_delete(const char *filename) {
    if (!check_permission(filename, PERM_OWNER_W, PERM_OTHER_W)) {
        printf(RED "  Permission denied: delete on '%s'\n" RESET, filename);
        audit("DELETE_DENIED", filename);
        return 0;
    }
    char fp[256], mp[256];
    file_path(filename, fp);
    meta_path(filename, mp);
    remove(fp);
    remove(mp);
    printf(YELLOW "  Deleted '%s'.\n" RESET, filename);
    audit("DELETE", filename);
    return 1;
}

/* ENCRYPT — XOR-encrypt a file, save as filename.enc */
int fs_encrypt(const char *filename) {
    if (!check_permission(filename, PERM_OWNER_R, PERM_OTHER_R)) {
        printf(RED "  Permission denied: encrypt on '%s'\n" RESET, filename);
        return 0;
    }
    char fp[256], enc_fp[256];
    file_path(filename, fp);
    char enc_name[256];
    snprintf(enc_name, sizeof(enc_name), "%s.enc", filename);
    file_path(enc_name, enc_fp);

    xor_crypt(fp, enc_fp);
    write_meta(enc_name, current_user.username, 0600); /* owner r/w only */
    printf(GREEN "  Encrypted '%s' → '%s'\n" RESET, filename, enc_name);
    audit("ENCRYPT", filename);
    return 1;
}

/* DECRYPT — XOR-decrypt a .enc file back */
int fs_decrypt(const char *enc_filename) {
    if (!check_permission(enc_filename, PERM_OWNER_R, PERM_OTHER_R)) {
        printf(RED "  Permission denied: decrypt on '%s'\n" RESET, enc_filename);
        return 0;
    }
    char fp[256], dec_fp[256];
    file_path(enc_filename, fp);

    /* strip .enc to get original name */
    char dec_name[256];
    strncpy(dec_name, enc_filename, sizeof(dec_name));
    char *dot = strstr(dec_name, ".enc");
    if (dot) *dot = '\0';
    strcat(dec_name, ".dec");

    file_path(dec_name, dec_fp);
    xor_crypt(fp, dec_fp);
    write_meta(dec_name, current_user.username, 0600);
    printf(GREEN "  Decrypted '%s' → '%s'\n" RESET, enc_filename, dec_name);
    audit("DECRYPT", enc_filename);
    return 1;
}

/* LIST FILES */
void fs_list(void) {
    printf(BOLD "\n  ── Files in %s/ ──\n" RESET, FILES_DIR);
    char cmd[256];
    snprintf(cmd, sizeof(cmd), "ls -1 %s/ 2>/dev/null | grep -v '^\\..*\\.meta$'", FILES_DIR);

    FILE *p = popen(cmd, "r");
    if (!p) { printf(DIM "  (empty)\n" RESET); return; }

    char fname[256];
    int found = 0;
    while (fgets(fname, sizeof(fname), p)) {
        fname[strcspn(fname, "\n")] = 0;
        if (strstr(fname, ".meta")) continue;

        char owner[MAX_USERNAME];
        int perm = 0;
        char pstr[10];
        if (read_meta(fname, owner, &perm)) {
            perm_to_str(perm, pstr);
            printf("  %s%-28s" RESET " %s  owner: %s\n",
                   CYAN, fname, pstr, owner);
        } else {
            printf("  %s%s" RESET "\n", CYAN, fname);
        }
        found = 1;
    }
    pclose(p);
    if (!found) printf(DIM "  (no files)\n" RESET);
    printf("\n");
}

/* SHOW AUDIT LOG */
void show_audit(void) {
    printf(BOLD "\n  ── Audit Log ──\n" RESET);
    FILE *f = fopen(AUDIT_LOG, "r");
    if (!f) { printf(DIM "  (no log entries yet)\n" RESET); return; }
    char line[256];
    while (fgets(line, sizeof(line), f))
        printf(DIM "  %s" RESET, line);
    fclose(f);
    printf("\n");
}

/* ─────────────────────────────────────────────────
   DEMO — runs a scripted walkthrough automatically
   so the marker can see all features without
   typing anything manually
───────────────────────────────────────────────── */
void run_demo(void) {
    /* Make files directory */
    mkdir(FILES_DIR, 0755);

    print_header();
    printf(BOLD YELLOW "\n  ══ DEMO MODE — running full feature walkthrough ══\n\n" RESET);

    /* ── Authentication ── */
    printf(BOLD "  [1] USER AUTHENTICATION\n" RESET);
    register_user("manjil123", "pass123", 1);   /* owner */
    register_user("manjil456", "pass456",  0);   /* regular user */
    printf("\n");

    login("manjil123", "wrongpassword");        /* deliberate fail */
    login("manjil123", "pass123");              /* success */
    printf("\n");

    /* ── File creation ── */
    printf(BOLD "  [2] FILE CREATION WITH PERMISSIONS\n" RESET);
    /*
     * 0640 = owner:rw-  group:r--  others:---
     * owner can read/write, others cannot write
     */
    fs_create("notes.txt",
              "This is manjil123's private notes.\nLine 2 of notes.\n",
              0640);
    fs_create("public.txt",
              "This file is readable by everyone.\n",
              0644);  /* 0644 = owner:rw- others:r-- */
    fs_list();

    /* ── Read / Write ── */
    printf(BOLD "  [3] READ AND WRITE\n" RESET);
    fs_read("notes.txt");
    fs_write("notes.txt", "Appended line by manjil123.\n");
    fs_read("notes.txt");

    /* ── Encryption ── */
    printf(BOLD "\n  [4] ENCRYPTION\n" RESET);
    fs_encrypt("notes.txt");
    fs_decrypt("notes.txt.enc");
    fs_read("notes.txt.dec");   /* should match original */

    /* ── Permission denial as another user (manjil456) ── */
    printf(BOLD "\n  [5] PERMISSION SYSTEM — login as manjil456\n" RESET);
    logout();
    login("manjil456", "pass456");

    printf("\n  manjil456 tries to read notes.txt (others has no read — 0640):\n");
    fs_read("notes.txt");        /* should be DENIED */

    printf("\n  manjil456 tries to read public.txt (others has read — 0644):\n");
    fs_read("public.txt");       /* should be ALLOWED */

    printf("\n  manjil456 tries to delete notes.txt (no write permission):\n");
    fs_delete("notes.txt");      /* should be DENIED */

    /* ── Audit log ── */
    logout();
    printf(BOLD "\n  [6] AUDIT LOG\n" RESET);
    show_audit();

    printf(BOLD GREEN "  ══ Demo complete. ══\n\n" RESET);
}

/* ─────────────────────────────────────────────────
   MAIN
───────────────────────────────────────────────── */
int main(void) {
    run_demo();
    return 0;
}