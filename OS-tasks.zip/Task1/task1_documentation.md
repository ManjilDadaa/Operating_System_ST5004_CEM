# Task 1 — Process Management and Threading

**Module:** ST5004CEM — Operating Systems and Security  
**Language:** C (compiled with GCC, POSIX threads)

---

## What this task is about

When you open your laptop and run Spotify, a browser, and a code editor all at the same time — the OS is not actually running all three simultaneously on one core. It's switching between them so fast that it *feels* like they're running at the same time. That switching, scheduling, and making sure they don't crash into each other is exactly what this task is about — just implemented in a smaller, controlled way in C.

This program creates three threads, gives each of them work to do, schedules them in round-robin order, and makes sure they don't corrupt shared data while doing it.

---

## Terminology you need to know

**Process** — a running program. When you double-click an app, the OS creates a process for it. A process has its own memory space.

**Thread** — a lighter unit of work that lives *inside* a process. Multiple threads share the same memory. Think of a process as a restaurant and threads as the waiters — they all work in the same building and share the same kitchen.

**Concurrency** — multiple things making progress in overlapping time. Does not necessarily mean they're running at the exact same instant (that's *parallelism*). On a single-core CPU, threads take turns very quickly — that's concurrency.

**Race condition** — a bug that only happens when two threads access shared data at the same time, and the result depends on who got there first. Like two people editing the same Google Doc cell simultaneously — whatever the last save was "wins", and the other person's change disappears silently.

**Mutex (Mutual Exclusion lock)** — a lock that only one thread can hold at a time. If Thread A holds the lock, Thread B has to wait. This prevents race conditions on shared data.

**Critical section** — the piece of code that touches shared data. The rule is: only one thread in the critical section at a time.

**Deadlock** — when two or more threads are each waiting for the other to release a lock, so none of them can ever proceed. Classic example: Thread A holds Lock 1 and waits for Lock 2. Thread B holds Lock 2 and waits for Lock 1. Both wait forever.

**Round-robin scheduling** — a simple scheduling algorithm where each thread/process gets a fixed time slot (called a time slice) in order, cycling back to the first one after the last. 0 → 1 → 2 → 0 → 1 → 2 → ...

**Condition variable** — a mechanism that lets a thread sleep and wait until some condition becomes true, without wasting CPU cycles by constantly checking in a loop.

**Semaphore** — similar to a mutex but can allow more than one thread through at once. A mutex is basically a semaphore with a limit of 1.

**pthreads (POSIX Threads)** — the standard C library for threads on Linux/Unix. "POSIX" just means it follows a standard that works across different Unix-based systems.

---

## How the program is structured

The program has four main pieces working together:

```
┌─────────────────────────────────────────┐
│              Main Function              │
│  - Initializes locks and variables      │
│  - Spawns 3 threads                     │
│  - Waits for all 3 to finish            │
└────────────────┬────────────────────────┘
                 │ creates
    ┌────────────┼────────────┐
    ▼            ▼            ▼
Thread 0     Thread 1     Thread 2
    │            │            │
    └────────────┴────────────┘
         │ all share
    ┌────▼─────────────────────┐
    │   shared_counter (int)   │
    │   current_turn (int)     │
    │   counter_mutex          │
    │   scheduler_mutex        │
    │   turn_cond              │
    └──────────────────────────┘
```

Every thread runs the same function (`thread_task`) but each gets its own ID (0, 1, or 2) so it knows who it is.

---

## The shared counter and why it needs protection

```c
int shared_counter = 0;
pthread_mutex_t counter_mutex;
```

`shared_counter` is the shared data — all three threads read it and write to it. The plan is simple: each time a thread finishes a round of work, it increments the counter by 1. Since there are 3 threads doing 3 rounds each, the final value should be 9.

The problem is that `shared_counter++` is not one operation. At the machine level it breaks down into three steps:

1. Read the current value from memory into a CPU register
2. Add 1 to it
3. Write it back to memory

If Thread 0 is halfway through step 2 and Thread 1 also reads the value in step 1, they both start from the same number and only one increment actually sticks. The counter ends up wrong — and the worst part is it doesn't always happen, so the bug is hard to reproduce.

`counter_mutex` fixes this. Before touching `shared_counter`, a thread locks the mutex. After it's done, it unlocks. The lock guarantees only one thread is ever inside those three machine steps at once.

```c
pthread_mutex_lock(&counter_mutex);
shared_counter++;
printf("[Thread %d] Shared counter is now: %d\n", id, shared_counter);
pthread_mutex_unlock(&counter_mutex);
```

Lock → do the work → unlock. This pattern is called protecting a **critical section**.

---

## The round-robin scheduler

```c
int current_turn = 0;
pthread_mutex_t scheduler_mutex;
pthread_cond_t  turn_cond;
```

These three variables together form the scheduler. `current_turn` holds the ID of whichever thread is allowed to work right now. It starts at 0.

`scheduler_mutex` protects `current_turn` itself — you can't let two threads change whose turn it is at the same time.

`turn_cond` is the condition variable. Without it, threads would have to do something like this to wait for their turn:

```c
// Bad approach — "busy waiting" / "spin lock"
while (current_turn != id) {
    // do nothing, just keep checking
}
```

This wastes CPU — the thread is doing nothing but burning cycles checking a variable. A condition variable is the proper solution: the thread **goes to sleep** and only wakes up when signalled. Zero CPU usage while waiting.

Here's how a thread waits for its turn:

```c
pthread_mutex_lock(&scheduler_mutex);
while (current_turn != id) {
    pthread_cond_wait(&turn_cond, &scheduler_mutex);
}
pthread_mutex_unlock(&scheduler_mutex);
```

`pthread_cond_wait` does two things at once — it releases `scheduler_mutex` and puts the thread to sleep. When it wakes up, it re-acquires the lock and checks the `while` condition again. The reason it's a `while` and not an `if` is that pthreads can sometimes wake a thread for no real reason (called a **spurious wakeup**), so you always check the condition again before proceeding.

After a thread finishes its round, it passes the turn:

```c
pthread_mutex_lock(&scheduler_mutex);
current_turn = (current_turn + 1) % NUM_THREADS;
pthread_cond_broadcast(&turn_cond);
pthread_mutex_unlock(&scheduler_mutex);
```

`(current_turn + 1) % NUM_THREADS` is the wraparound. With 3 threads: 0+1=1, 1+1=2, 2+1=3, 3%3=0. So it cycles back to 0. That's the round-robin.

`pthread_cond_broadcast` wakes every sleeping thread so they can each check if it's their turn now. Only one of them will find `current_turn == id` and proceed. The rest go back to sleep.

---

## Passing data to threads

Threads in C get exactly one argument, and it must be `void *` (a generic pointer). To give each thread its ID, a struct is used:

```c
typedef struct {
    int thread_id;
} ThreadArgs;
```

Inside the thread function, the first thing done is casting it back to the right type:

```c
ThreadArgs *args = (ThreadArgs *)arg;
int id = args->thread_id;
```

This is standard practice in C threading. The struct can hold more fields if needed — for this task, just the ID is enough.

---

## Deadlock prevention

Two mutexes are used in this program: `counter_mutex` and `scheduler_mutex`. Deadlock could happen if Thread A locked `counter_mutex` and then tried to lock `scheduler_mutex`, while Thread B did the opposite at the same time.

The prevention strategy used here is **lock ordering** — in the code, if both locks are ever needed, `scheduler_mutex` is always acquired before `counter_mutex`, never the other way around. Since all threads follow the same order, the circular waiting condition that causes deadlock can never form.

Additionally, the two mutexes are never held at the same time. The scheduler lock is released before the counter lock is acquired:

```c
pthread_mutex_unlock(&scheduler_mutex);   // ← release scheduler lock first

pthread_mutex_lock(&counter_mutex);       // ← then acquire counter lock
shared_counter++;
pthread_mutex_unlock(&counter_mutex);

pthread_mutex_lock(&scheduler_mutex);     // ← then back to scheduler
current_turn = (current_turn + 1) % NUM_THREADS;
...
pthread_mutex_unlock(&scheduler_mutex);
```

Never holding both at once means there's no opportunity for a circular wait.

---

## What happens when you run it

All three threads get spawned nearly instantly. Threads 1 and 2 immediately go to sleep on `turn_cond` because `current_turn` is 0. Thread 0 proceeds with its first round.

After Thread 0 finishes, it sets `current_turn = 1` and broadcasts. Thread 1 wakes up, checks its condition, sees it's its turn, and proceeds. Thread 0 and Thread 2 are both asleep.

This continues until all threads have completed all 3 rounds. The output looks like:

```
=== Round-Robin Thread Scheduler ===
Threads: 3 | Time slice: 1s | Rounds each: 3

[Main] Thread 0 spawned.
[Main] Thread 1 spawned.
[Main] Thread 2 spawned.
[Thread 0] Round 1 — working for 1 second(s)...
[Thread 0] Shared counter is now: 1
[Thread 1] Round 1 — working for 1 second(s)...
[Thread 1] Shared counter is now: 2
[Thread 2] Round 1 — working for 1 second(s)...
[Thread 2] Shared counter is now: 3
...
[Thread 2] Finished all work.

=== All threads completed ===
Final shared counter value: 9
Expected: 9 (= 3 threads × 3 rounds)
```

The final counter is always 9. Every time. That's how you know the mutex is working — without it, the value would sometimes be wrong and the program would be non-deterministic.

---

## How to compile and run

Navigate to the `task1/` folder and run:

```bash
gcc -o scheduler main.c -lpthread
./scheduler
```

The `-lpthread` flag links the POSIX threads library. Without it, the compiler won't find `pthread_create` and similar functions.

---

## Design decisions

**Why condition variables instead of a spin-lock?**  
Spin-locks waste CPU by constantly looping. Condition variables put threads to sleep and wake them only when relevant — much more efficient and the right tool for this kind of synchronization.

**Why `pthread_cond_broadcast` instead of `pthread_cond_signal`?**  
`signal` wakes one arbitrary thread. If it wakes the wrong one (not the one whose turn it is), that thread just goes back to sleep, and no one proceeds — the program stalls. `broadcast` wakes all of them safely, and only the correct one will actually do anything.

**Why a struct for thread arguments?**  
Future-proofing. Right now only the ID is needed, but if the program needed to pass a work queue, a timeout, or a priority level to each thread, you'd just add fields to the struct — no other changes needed.

**Why `while` and not `if` for the condition check?**  
Spurious wakeups. The POSIX standard explicitly allows condition variables to wake a thread even without a signal being sent. The `while` loop re-checks the condition every time the thread wakes up, making the code correct regardless.

---

## Summary

This program demonstrates four core OS threading concepts in one place. Threads let work happen concurrently. Mutexes protect shared data from race conditions. Condition variables let threads wait efficiently without wasting CPU. And the round-robin scheduler shows how an OS fairly distributes CPU time between competing threads — the same fundamental idea behind how your operating system handles processes every second your computer is running.
